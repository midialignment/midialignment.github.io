#ifndef SCROLLBAR_H
#define SCROLLBAR_H

#include <iostream>
#include <QObject>
#include <QPen>
#include <QGraphicsLineItem>
#include <QGraphicsItemAnimation>
#include <QTimeLine>


class ScrollBar : public QObject
{
  Q_OBJECT

public:
  explicit ScrollBar(
      double x, double y, double w, double h,
      double pxPerSec,
      QObject * parent = 0) : QObject(parent)
  {
    // Setting Line
    this->line = new QGraphicsLineItem(x, y, x, y+h);
    this->line->setPen(QPen(Qt::red, 3));
    // Setting Time Line
    this->timeline = new QTimeLine((int)(w / pxPerSec * 1000));
    this->timeline->setCurveShape(QTimeLine::LinearCurve);
    this->timeline->setUpdateInterval(1);
    // Setting Animation
    this->animation = new QGraphicsItemAnimation;
    this->animation->setItem(this->line);
    this->animation->setTimeLine(this->timeline);
    this->animation->setPosAt(1, QPointF(w, 0.0));

    connect(this->timeline, SIGNAL(finished()),
            this, SIGNAL(finished()));
  }

  void initialize(
      double x, double y, double w, double h,
      double pxPerSec)
  {
    // Setting Line
    this->line->setLine(x, y, x, y+h);
    // Setting Time Loine
    this->timeline->setDuration((int)(w / pxPerSec * 1000));
    // Setting Animation
    this->animation->setPosAt(1, QPointF(x+w, 0.0));
  }

signals:
  void finished();

public slots:

  void start()
  {
    std::cerr << "[START]" << std::endl;
    this->timeline->resume();
  }

  void stop()
  {
    std::cerr << "[STOP]" << std::endl;
    this->timeline->stop();
  }

  void changePos(int millisec)
  {
//    std::cerr << "[Change Pos]" << std::endl;
    this->timeline->setCurrentTime(millisec);
  }

  QGraphicsLineItem * getPtr()
  {
    return this->line;
  }

private:
  QGraphicsLineItem * line;
  QGraphicsItemAnimation * animation;
  QTimeLine * timeline;
};


#endif // SCROLLBAR_H
