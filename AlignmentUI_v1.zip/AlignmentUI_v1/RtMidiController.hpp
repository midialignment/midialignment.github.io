#ifndef __RTMIDI_CONTROLLER_HPP__
#define __RTMIDI_CONTROLLER_HPP__

#include "RtMidi.h"
#include <memory>
#include <cassert>

#include <iostream>

class RtMidiController
{
public:
  RtMidiController() :
      midiin_(nullptr), midiout_(nullptr)
  {
    try {
      // midiin_ = std::make_unique<RtMidiIn>();
    }
    catch (const RtMidiError & e) {
      e.printMessage();
      exit(EXIT_FAILURE);
    }

    try {
      // midiout_ = std::make_unique<RtMidiOut>();
      midiout_.reset(new RtMidiOut());
    }
    catch (const RtMidiError & e) {
      e.printMessage();
      exit(EXIT_FAILURE);
    }
  }

  ~RtMidiController()
  {
    this->sendInitializer();
  }

  void openInputDevice(unsigned int portNumber)
  {
    assert(portNumber < midiin_->getPortCount());
    this->closeInputDevice();
    midiin_->openPort(portNumber);
    isReadyMidiIn_ = true;
  }

  void openOutputDevice(unsigned int portNumber)
  {
    assert(portNumber < midiout_->getPortCount());
    this->closeOutputDevice();
    midiout_->openPort(portNumber);
    isReadyMidiOut_ = true;
  }

  void openVirtualOutputDevise()
  {
    midiout_->openVirtualPort();
    isReadyMidiOut_ = true;
  }

  void close()
  {
    this->closeInputDevice();
    this->closeOutputDevice();
  }

  void closeInputDevice()
  {
    midiin_->closePort();
    isReadyMidiIn_ = false;
  }

  void closeOutputDevice()
  {
    midiout_->closePort();
    isReadyMidiOut_ = false;
  }

  int getInputPortCount()  const
  {
    return midiin_->getPortCount();
  }

  int getOutputPortCount() const
  {
    return midiout_->getPortCount();
  }

  // std::string getInputPortName(unsigned int num) const
  // {
  //   unsigned int numPort = this->getInputPortCount();
  //   assert(num < numPort);
  //   return midiin_.getPortName(num);
  // }

  std::string getOutputPortName(unsigned int num) const
  {
    unsigned int numPort = this->getOutputPortCount();
    assert(num < numPort);
    return midiout_->getPortName(num);
  }

  std::vector<std::string> getOutputPortNameList() const
  {
    std::vector<std::string> ports(this->getOutputPortCount());
    for (int i = 0; i < ports.size(); i++) {
      ports[i] = this->getOutputPortName(i);
    }
    return ports;
  }

  void sendMessage(std::vector<unsigned char> & msg)
  {
    if (msg.empty()) return;
    if (!isReadyMidiOut_) return;
    midiout_->sendMessage(&msg);
  }

  void sendInitializer()
  {
    if (!isReadyMidiOut_) return;

    std::vector<unsigned char> msg0{ 0xB0, 0x78, 0x00 };
    for (int i = 0; i < 16; i++) {
        midiout_->sendMessage(&msg0);
        msg0[0]++;
    }

    // set volume
    std::vector<unsigned char> msg1{ 0xB0, 0x07, 100 };
    for (int i = 0; i < 16; i++) {
        midiout_->sendMessage(&msg1);
        msg1[0]++;
    }

    // set instrument
    std::vector<unsigned char> msg2{ 0xC0, 0x00 };
    for (int i = 0; i < 16; i++) {
        midiout_->sendMessage(&msg2);
        msg2[0]++;
    }
  }

  void sendAllNoteOff()
  {
    if (!isReadyMidiOut_) return;

    std::vector<unsigned char> noteoff_msg{ 0xB0, 0x78, 0x00 };
    std::vector<unsigned char>   reset_msg{ 0xB0, 0x79, 0x00 };
    for (int i = 0; i < 16; i++) {
      midiout_->sendMessage(&noteoff_msg);
      midiout_->sendMessage(&reset_msg);
      noteoff_msg[0]++;
      reset_msg[0]++;
    }
  }

private:
  std::unique_ptr<RtMidiIn>  midiin_;
  std::unique_ptr<RtMidiOut> midiout_;
  bool isReadyMidiIn_;
  bool isReadyMidiOut_;
};



#endif
