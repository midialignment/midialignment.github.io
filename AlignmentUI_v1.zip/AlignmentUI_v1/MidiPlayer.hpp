#ifndef __MIDI_PLAYER_HPP__
#define __MIDI_PLAYER_HPP__

#include <iostream>
#include <algorithm>
#include <thread>
#include <cstdio>
#include <cassert>
#include "Midi_v170101.hpp"
#include "RtMidiController.hpp"
#include "ElapsedTimer.hpp"


#ifndef __WINDOWS_MM__
  #include <sys/time.h>
  #define SLEEP(milliseconds) struct timespec spec{ 0, milliseconds * 1000000 };  nanosleep(&spec, NULL)
#else
  #include <windows.h>
  #define SLEEP(milliseconds) Sleep((DWORD)milliseconds)
#endif

struct Track
{
public:
  typedef std::vector<MidiMessage>::iterator Iterator;

  Track() : midi_(), head_(midi_.content.begin()), mute_(true) {}

  void setMidi(const Midi & midi)
  {
    midi_ = midi;
    head_ = midi_.content.begin();
  }

  void setHeadTime(const int secTime)
  {
    head_ = midi_.content.begin();
    for (; head_ != midi_.content.end() && head_->time < secTime; head_++);
    //std::lower_bound(midi_.content.begin(), midi_.content.end(), msg, LessTickMidiMessage());
  }

  const Iterator & head() const { return head_; }

  Iterator begin() { return midi_.content.begin(); }
  Iterator   end() { return midi_.content.end();   }
  bool   hasNext() const { return head_ != midi_.content.end();   }
  bool   hasPrev() const { return head_ != midi_.content.begin(); }

  Iterator next() { Iterator tmp = head_; head_++; return tmp; }
  Iterator prev() { Iterator tmp = head_; head_--; return tmp; }

  void muteOn () { mute_ = true;  }
  void muteOff() { mute_ = false; }
  bool isMute() const { return mute_; }

private:
  Midi     midi_;
  Iterator head_;
  bool     mute_;
};

class TimeManager
{
public:
  TimeManager()
  : startPoint_(0)
  , prevTime_(0)
  , currTime_(0)
  , timer_()
  {}

  void start(double sp)
  {
    prevTime_   = sp;
    currTime_   = sp;
    startPoint_ = sp;
    timer_.start();
  }

  void update()
  {
    prevTime_ = currTime_;
    currTime_ = timer_.getElapsedTimeInSec() + startPoint_;
  }

  double previousTime() const { return prevTime_; }
  double currentTime()  const { return currTime_; }

private:
  double startPoint_;
  double prevTime_;
  double currTime_;
  ElapsedTimer timer_;
};


class MidiPlayer
{
public:
  // Constructor
  MidiPlayer()
  : is_stop_(true)
  , is_processEnd_(true)
  , numTrack_(16)
  , soloTrack_(0)
  , track_(numTrack_)
  , controller_()
  , timer_()
  { }

  /*
  void loadIpr(const std::string & iprFile, const int track = 0)
  {
    PianoRoll pianoroll;
    pianoroll.ReadFileIpr(iprFile);
    track_[track].setMidi(pianoroll.ToMidi());
  }
  */

  void setMidi(const Midi & midi, const int track = 0)
  {
    assert(0 <= track && track < 16);
    track_[track].setMidi(midi);
  }
/*
  void selectOutputDevise()
  {
    int numPort = controller_.getOutputPortCount();
    controller_.closeOutputDevice();
    std::cout << "[  Select Port  ]" << std::endl;
    std::cout << std::flush;
    for (int i = 0; i < numPort; i++) {
      std::cout << "[" << i << "] " << controller_.getOutputPortName(i) << std::endl;
    }
    int n = 0;
    std::cout << "> ";
    std::cin  >> n;
    controller_.openOutputDevice(n);
    // controller_.openVirtualOutputDevise();
  }
*/
  void selectOutputDevise(int n)
  {
    int numPort = controller_.getOutputPortCount();
    if (numPort == 0) return;
    assert(0 <= n && n < numPort);
    controller_.openOutputDevice(n);
  }

  void muteOn (int n) { track_[n].muteOn();  }
  void muteOff(int n) { track_[n].muteOff(); }
  void soloOn (int n) { assert(0 <= n && n < numTrack_); soloTrack_ = n;  }
  void soloOff()      { soloTrack_ = -1; }

  void start(const double startTimeInSec = 0.0)
  {
    this->stop();
    while (!is_processEnd_);

    is_stop_ = false;

    timer_.start(startTimeInSec);
    for (int i = 0; i < numTrack_; i++) {
      track_[i].setHeadTime(startTimeInSec);
    }

    std::thread th(&MidiPlayer::process, this);
    th.detach();
  }

  void stop()
  {
    is_stop_ = true;
  }

  double getCurrentTime() const
  {
    return timer_.currentTime();
  }


private:

  void process()
  {
    is_processEnd_ = false;
    while (!is_stop_) {
      this->timeUpdate();
      this->sendMessage();
      SLEEP(1);
    }
    controller_.sendAllNoteOff();
    is_processEnd_ = true;
  }

  void timeUpdate()
  {
    timer_.update();
    // printf("\r%f", timer_.currentTime());
    // fflush(stdout);
  }

  void sendMessage()
  {
    for (int i = 0; i < numTrack_; i++) {
      if (track_[i].isMute()) continue;
      if (soloTrack_ >= 0 && i != soloTrack_) continue;
      while (track_[i].hasNext()) {
        Track::Iterator it = track_[i].next();
        if (it->time > timer_.currentTime()) {
          track_[i].prev();
          break;
        }
        std::vector<unsigned char> msg(it->mes.begin(), it->mes.end());
        controller_.sendMessage(msg);
      }
    }
  }

public:

  bool    is_stop_;
  bool    is_processEnd_;
  int     numTrack_;
  int     soloTrack_;

  std::vector<Track>  track_;
  RtMidiController    controller_;
  TimeManager         timer_;
};

#endif
